<?php
// Inclure la connexion à la base de données
include ("../../../../include_bdd/connexion.bdd.php");

// Vérification de la méthode de requête
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer l'ID de la demande d'essai à terminer
    $id_demande_essai = intval($_POST['id_demande_essai']);

    // Mise à jour de l'état de la demande d'essai à "terminé"
    $updateEtat = "UPDATE `demande_essai` SET `etat` = 'terminé' WHERE `id_demande_essai` = ?";
    $stmt = $connexion->prepare($updateEtat);
    $stmt->bind_param("i", $id_demande_essai);
    $stmt->execute();

    // Récupérer le nom du modèle lié à la demande
    $getModeleName = "SELECT `nom_modele` FROM `demande_essai` WHERE `id_demande_essai` = ?";
    $stmt = $connexion->prepare($getModeleName);
    $stmt->bind_param("i", $id_demande_essai);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $nom_modele = $row['nom_modele'];

    // Incrémenter le nombre d'essais pour le modèle
    $updateEssai = "UPDATE `modele` SET `nombre_essaie` = `nombre_essaie` + 1 WHERE `nom_modele` = ?";
    $stmt = $connexion->prepare($updateEssai);
    $stmt->bind_param("s", $nom_modele);
    $stmt->execute();

    // Redirection après mise à jour
    header("Location: ../voir_demande.php");
    exit();
}

// Fermer la connexion
$connexion->close();
?>
