<?php
session_start();
// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['identifiant'])) {
    // Rediriger vers la page de connexion s'il n'est pas connecté
    header("Location: ../../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visite clients</title>

    <!-- FICHIER CSS DE BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
<?php
    // Mettre en ligne la connexion avec la base de données
    include("../../include_bdd/connexion.bdd.php");

    // Vérifier la connexion
    if ($connexion->connect_error) {
        die("Connexion échouée: " . $connexion->connect_error);
    }

    // Requête SQL pour récupérer la liste des visites
    $sql = "SELECT * FROM `visite`";
    $resultat = $connexion->query($sql);
?>

<div class="container mt-5">
    <h1>Nombre de visites</h1>

    <?php
    // Vérifier si des résultats sont retournés
    if ($resultat->num_rows > 0) {
        // Afficher chaque visite
        while($row = $resultat->fetch_assoc()) {
            echo "<p>Nombre de visites : " . $row['nombre_visites'] . "</p>";
        }
    } else {
        echo "<p>Aucune visite trouvée.</p>";
    }
    ?>
</div>

<!-- FICHIER JS DE BOOTSTRAP -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
