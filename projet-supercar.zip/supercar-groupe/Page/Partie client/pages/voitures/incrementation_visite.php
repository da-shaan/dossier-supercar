<?php
// Inclure la connexion à la base de données
include('../../include_bdd/connexion.bdd.php');

// Vérifiez si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer l'ID de la voiture depuis le formulaire
    $id_voiture = $_POST['id_voiture'];

    // Incrémenter la colonne nombre_visite
    $query = "UPDATE voitures SET nombre_visites = nombre_visites + 1 WHERE id_voiture = ?";
    
    // Préparer et exécuter la requête
    if ($stmt = $connexion->prepare($query)) {
        $stmt->bind_param("i", $id_voiture); // Lier l'ID de la voiture
        $stmt->execute();

        // Vérifier si la mise à jour a réussi
        if ($stmt->affected_rows > 0) {
            // Rediriger l'utilisateur vers la page des détails de la voiture
            header("Location: affichage_details.php?id=" . $id_voiture);
            exit();
        } else {
            echo "Erreur lors de la mise à jour du compteur de visites.";
        }
    } else {
        echo "Erreur de préparation de la requête.";
    }
}
?>
